package com.example.platoaim

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import kotlin.math.hypot

class AimOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var toolbar: LinearLayout? = null
    private var drawing: AimView? = null
    private var editing = true
    private lateinit var canvasParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showOverlay()
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        canvasParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        canvasParams.gravity = Gravity.TOP or Gravity.START
        val view = AimView()
        drawing = view
        wm.addView(view, canvasParams)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 4)
            setBackgroundColor(0xCC17212B.toInt())
        }
        val mode = Button(this).apply { text = "ล็อกเส้น"; setOnClickListener { toggleMode(this) } }
        val close = Button(this).apply { text = "ปิด ×"; setOnClickListener { stopSelf() } }
        bar.addView(mode)
        bar.addView(close)
        toolbar = bar
        val barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            dp(48), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        barParams.gravity = Gravity.TOP or Gravity.START
        barParams.x = dp(8); barParams.y = dp(40)
        wm.addView(bar, barParams)
        updateTouchMode()
    }

    private fun toggleMode(button: Button) {
        editing = !editing
        button.text = if (editing) "ล็อกเส้น" else "ปรับเส้น"
        updateTouchMode()
    }

    private fun updateTouchMode() {
        canvasParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!editing) canvasParams.flags = canvasParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        drawing?.let { wm.updateViewLayout(it, canvasParams) }
        drawing?.invalidate()
    }

    override fun onDestroy() {
        drawing?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        toolbar?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        drawing = null
        toolbar = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private inner class AimView : View(this@AimOverlayService) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // Normalized positions: cue ball, object ball, cushion bounce point, projected endpoint.
        private var cue = Pair(.18f, .72f)
        private var obj = Pair(.43f, .48f)
        private var bounce = Pair(.62f, .12f)
        private var active = -1

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            // Subtle guide frame; the game remains visible beneath the transparent view.
            p.color = 0x99FFFFFF.toInt(); p.style = Paint.Style.STROKE; p.strokeWidth = 2f
            canvas.drawRoundRect(RectF(w*.06f, h*.08f, w*.94f, h*.92f), 18f, 18f, p)
            // Continuous single polyline: cue -> object -> cushion -> reflected path.
            val c = point(cue, w, h); val o = point(obj, w, h); val b = point(bounce, w, h)
            val end = Pair((bounce.first + (bounce.first - obj.first)*.72f).coerceIn(.04f,.96f), (bounce.second - (bounce.second - obj.second)*.72f).coerceIn(.04f,.96f))
            val e = point(end, w, h)
            p.color = Color.WHITE; p.strokeWidth = 4f; p.style = Paint.Style.STROKE
            val path = Path().apply { moveTo(c.first,c.second); lineTo(o.first,o.second); lineTo(b.first,b.second); lineTo(e.first,e.second) }
            canvas.drawPath(path, p)
            drawNode(canvas, c.first, c.second, "C", Color.CYAN)
            drawNode(canvas, o.first, o.second, "O", Color.YELLOW)
            drawNode(canvas, b.first, b.second, "B", Color.MAGENTA)
            p.style = Paint.Style.FILL; p.color = 0xCC101820.toInt()
            canvas.drawRoundRect(RectF(12f, 12f, 300f, 52f), 12f, 12f, p)
            p.color = Color.WHITE; p.textSize = 13f
            canvas.drawText(if (editing) "โหมดปรับ: ลากจุด C / O / B" else "ล็อกแล้ว: สัมผัสผ่านไปยังเกม", 24f, 38f, p)
        }

        private fun point(v: Pair<Float,Float>, w: Float, h: Float) = Pair(v.first*w, v.second*h)
        private fun drawNode(canvas: Canvas, x: Float, y: Float, label: String, color: Int) {
            p.style = Paint.Style.FILL; p.color = color; canvas.drawCircle(x,y,dp(11).toFloat(),p)
            p.color = Color.BLACK; p.textSize = dp(11).toFloat(); p.textAlign = Paint.Align.CENTER
            canvas.drawText(label,x,y+dp(4).toFloat(),p); p.textAlign = Paint.Align.LEFT
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (!editing) return false
            val w = width.toFloat(); val h = height.toFloat()
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    val pts = listOf(cue,obj,bounce)
                    active = pts.indices.minByOrNull { i ->
                        val q = point(pts[i],w,h); hypot(event.x-q.first,event.y-q.second)
                    } ?: -1
                    return active >= 0
                }
                MotionEvent.ACTION_MOVE -> {
                    val v = Pair((event.x/w).coerceIn(.03f,.97f),(event.y/h).coerceIn(.03f,.97f))
                    when(active) { 0 -> cue=v; 1 -> obj=v; 2 -> bounce=v }
                    invalidate(); return true
                }
                MotionEvent.ACTION_UP -> { active=-1; performClick(); return true }
            }
            return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
    }
}
