package com.example.platoaim

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xFF101820.toInt())
        }
        val title = TextView(this).apply {
            text = "PLATO POOL AIM\nASSISTANT"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "เครื่องมือฝึกเล็งแบบหน้าต่างลอย\nแตะจุดลูกขาว จุดลูกเป้าหมาย และจุดสะท้อนเพื่อปรับแนวเส้น\n\nหมายเหตุ: เวอร์ชันนี้ยังไม่ตรวจจับลูกบอลอัตโนมัติ"
            textSize = 15f
            setTextColor(0xFFD8E1E8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(24))
        }
        val start = Button(this).apply {
            text = "เปิดหน้าต่างเส้นเล็ง"
            setOnClickListener { startOverlay() }
        }
        val how = Button(this).apply {
            text = "วิธีใช้งาน"
            setOnClickListener {
                info.text = "1. อนุญาตให้แสดงทับแอปอื่น\n2. เปิด Plato แล้วกลับมาเปิดหน้าต่างเส้นเล็ง\n3. แตะ ‘ปรับ’ แล้วลากจุด C (ลูกขาว), O (ลูกเป้า), B (จุดชนขอบ)\n4. แตะ ‘ล็อก’ เพื่อให้สัมผัสผ่านไปยังเกม\n5. ปิดด้วยปุ่ม ×\n\nเส้นเป็นแนวจำลองจากตำแหน่งที่ผู้ใช้กำหนด ไม่ได้อ่านสถานะเกม"
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(start, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(how, LinearLayout.LayoutParams(-1, dp(50)))
        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, AimOverlayService::class.java))
        finish()
    }
}
